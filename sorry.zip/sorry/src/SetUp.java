
import java.io.*;
import java.util.Scanner;

import sorryBoard.Card;
import sorryBoard.Deck;
import sorryBoard.Piece;

public class SetUp {
	
	//private Card card = new Card(1,1,false);
	
	public static void main(String[] args) {
		//ToDo Setup
		Scanner myObj = new Scanner(System.in);
		
		Deck d = new Deck();
		d.shuffle();
		int i = 0;
		int c = 0;
		int yeetus = 0;
		
		Piece p[] = new Piece[4];
		
		p[0] = new Piece("Blue");
		p[1] = new Piece("Yellow");
		p[2] = new Piece("Green");
		p[3] = new Piece("Red");
		
		//Play the game
		while(yeetus == 0) {
			for(i = 0; i < d.getSize(); i++) {	
				if(p[c%4].getDone() == true) {
					c++;
				} 
				else {
						
					// Say what turn it is
					
					if(c%4 == 0) {
						System.out.println("Blue's turn!");
					}
					else if(c%4 == 1) {
						System.out.println("Yellow's turn!");
					}
					else if(c%4 == 2) {
						System.out.println("Green's turn!");
					}
					else {
						System.out.println("Red's turn!");
					}
					
					//--------------------------------
					
					Card sel = d.draw(i);
					int val = sel.getValue();
					
					System.out.println(sel.toString());
					
					if(sel.getColor() == (c%4 + 1)) {
						System.out.println("Can use effect.");
						int hand = p[c%4].doEffect(sel.getValue(),sel.getFnch());
						if(hand == 1) {
							d.draw(i);
							d.draw(i);
							d.draw(i);
						}
						else if(hand == 3) {
							for(int o = 0; o < p.length; o++) {
								p[o].addSpace(-5);
							}
							p[c%4].addSpace(5);
						}
					}
					
					
					//------------------ Start ---------------------------
					
					if(val == 1 && p[c%4].getStart() == false || val == 2 && p[c%4].getStart() == false) {
							p[c%4].start();
					}
					else {
						if(val == 4) {
							val = -4;
						}
						if(p[c%4].getStart() == true) {
							if(c%4 == 0) {
								p[0].addSpace(val);
								p[0].loopSpace();
							}
							else if(c%4 == 1) {
								p[1].addSpace(val);
								p[1].loopSpace();
							}
							else if(c%4 == 2) {
								p[2].addSpace(val);
								p[2].loopSpace();
							}
							else {
								p[3].addSpace(val);
								p[3].loopSpace();
							}
						}
					}
					
					//--------------------------------------------------------
				
					myObj.nextLine();
					
					//Check the safe zone
					p[0].safeZone();
					p[1].safeZone();
					p[2].safeZone();
					p[3].safeZone();
					
					//Check if there are colliding pieces at the end of the turn
					for(int l = 0; l < p.length; l++) {
						if(l != c%4) {
							if(p[l].getSpace() == p[c%4].getSpace()) {
								p[l].reset();
							}
						}
					}
					
					if(d.draw(i).getValue() != 2){
						c++;
					}
					
					System.out.println(p[0].toString());
					System.out.println(p[1].toString());
					System.out.println(p[2].toString());
					System.out.println(p[3].toString());
					
					System.out.println("\n----------------------");
				}
			}
			if(p[0].getDone() && p[1].getDone() && p[2].getDone() && p[3].getDone()) {
				yeetus = 1;
				System.out.println("The game is over.");
				break;
			}
			d.shuffle();
		}
		
	}

	
}
