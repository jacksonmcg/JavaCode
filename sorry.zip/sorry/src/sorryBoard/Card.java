package sorryBoard;

public class Card {
	
	private int value;
	private int colorr;
	private String convColor;
	private int fnch;
	private boolean str;
	
	public Card(int val, int col, int fn) {
		value = val;
		colorr = col;
		convertColor(col);
		fnch = fn;
	}
	
	public int getValue(){
		return value;
	}
	public void setValue(int x){
		value = x;
	}
	
	public int getColor(){
		return colorr;
	}
	public void setColor(int x){
		value = x;
	}
	
	public int getFnch() {
		return fnch;
	}
	
	public void convertColor(int c) {
		if(c == 1) {
			convColor = "Blue";
		}
		else if(c == 2) {
			convColor = "Yellow";
		}
		else if(c == 3) {
			convColor = "Green";
		}
		else if(c == 4) {
			convColor = "Red";
		}
		else {
			convColor = "None";
		}
	}
	
	public String getCColor() {
		return convColor;
	}
	
	public boolean getStart(){
		return this.str;
	}
	public void setStart(boolean x){
		this.str = x;
	}
	
	public String toString() {
		String ret = "";
		if(convColor == "None") {
			switch(value) {
			case 1:
				 ret = "1: Start";
				 break;
			case 2:
				ret = "2: Start + Draw Again";
				 break;
			case 4:
				ret = "4: Backwards 4";
				 break;
			case 7:
				ret = "7: Split";
				 break;
			case 10:
				ret = "10: Move 10 or backwards 1";
				 break;
			case 11:
				ret = "11: Switch with player";
				 break;
			default:
				ret = "Something went wrong";
				 break;
			}
		}
		else {
			if(fnch == 1) {
				switch(value) {
				case 3:
					ret = "3: Go to home base if " + convColor;
					 break;
				case 5:
					ret = "5: Move all pieces 5 if " + convColor;
					 break;
				case 8:
					ret = "8: Check next 3 cards if " + convColor;
					 break;
				case 12:
					ret = "12: Move 24 if " + convColor;
					 break;
				default:
					ret = "Something went wrong";
					 break;
				}
			}
			else if(fnch == 2) {
				switch(value) {
				case 3:
					ret = "3: Check next 3 cards if " + convColor;
					 break;
				case 5:
					ret = "5: Move other player backwards 5 if " + convColor;
					 break;
				case 8:
					ret = "8: Move two pieces 8 if " + convColor;
					 break;
				case 12:
					ret = "12: Move closest piece to home base if " + convColor;
					 break;
				default:
					ret = "Something went wrong";
					 break;
				}
			}
			
		}
		return ret;	
	}
		
	}