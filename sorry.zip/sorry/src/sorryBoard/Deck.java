package sorryBoard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
	
	 private ArrayList<Card> allCards = new ArrayList<Card>();
	
	 
	 public Deck() {
		populateDeck(); 
	 }
	 
	 public void populateDeck() {
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(1,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(2,0,0));
		 allCards.add(new Card(3,1,1));
		 allCards.add(new Card(3,2,1));
		 allCards.add(new Card(3,3,1));
		 allCards.add(new Card(3,4,1));
		 allCards.add(new Card(3,1,2));
		 allCards.add(new Card(3,2,2));
		 allCards.add(new Card(3,3,2));
		 allCards.add(new Card(3,4,2));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(4,0,0));
		 allCards.add(new Card(5,1,1));
		 allCards.add(new Card(5,2,1));
		 allCards.add(new Card(5,3,1));
		 allCards.add(new Card(5,4,1));
		 allCards.add(new Card(5,1,2));
		 allCards.add(new Card(5,2,2));
		 allCards.add(new Card(5,3,2));
		 allCards.add(new Card(5,4,2));
		 //allCards.add(new Card(6,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(7,0,0));
		 allCards.add(new Card(8,1,1));
		 allCards.add(new Card(8,2,1));
		 allCards.add(new Card(8,3,1));
		 allCards.add(new Card(8,4,1));
		 allCards.add(new Card(8,1,2));
		 allCards.add(new Card(8,2,2));
		 allCards.add(new Card(8,3,2));
		 allCards.add(new Card(8,4,2));
		 //allCards.add(new Card(9,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(10,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(11,0,0));
		 allCards.add(new Card(12,1,1));
		 allCards.add(new Card(12,2,1));
		 allCards.add(new Card(12,3,1));
		 allCards.add(new Card(12,4,1));
		 allCards.add(new Card(12,1,2));
		 allCards.add(new Card(12,2,2));
		 allCards.add(new Card(12,3,2));
		 allCards.add(new Card(12,4,2));
	 }
	 
	 public void shuffle() {
		 Collections.shuffle(allCards);
		 System.out.println("Deck has been shuffled.");
	 }
	 
	 public Card draw(int x) {
		 return allCards.get(x);
	 }
	 
	 public int getSize() {
		 return allCards.size();
	 }
	 
}