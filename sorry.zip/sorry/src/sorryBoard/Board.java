package sorryBoard;

public class Board {
	
	
	public Board() {
		
	}
	
	private int loopBack(int a) {
		if(a == 57) {
			a = 0;
		}
		return a;
	}
}