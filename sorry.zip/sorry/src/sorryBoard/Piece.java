package sorryBoard;

public class Piece {
	
	Board board = new Board();
	private String color;
	private int space;
	private int counter;
	private boolean start;
	private boolean safe;
	private boolean done;
	
	public Piece(String x) {
		space = 0;
		counter = 1;
		color = x;
		start = false;
		safe = false;
		done = false;
	}
	
	public String getColor() {
		return color;
	}
	public void setColor(String c) {
		color = c;
	}
	
	public int getSpace() {
		return space;
	}
	public void setSpace(int s) {
		space = s;
	}
	
	public void addSpace(int x) {
		space = space + x;
		counter = counter + x;
		done(x);
	}
	
	public String toString() {
		String f = "";
		if(done == true) {
			f = getColor() + " is done.";
		} else if(getSpace() == 0) {
			f = getColor() + " is in START.";
		} 
		else if(safe == true) {
			int mes = counter - 60;
			f = getColor() + " is in the safe zone on space " + mes + ".";
		}
		else {
		f = getColor() + " is on space " + getSpace() + " and has moved " + counter + " spaces.";
		}
		return f;
	}
	
	public void start() {
		if(getColor() == "Blue") {
			 setSpace(5);
		}
		if(getColor() == "Yellow") {
			 setSpace(20);
		}
		if(getColor() == "Green") {
			 setSpace(35);
		}
		if(getColor() == "Red") {
			 setSpace(50);
		}
		start = true;
	}
	
	public boolean getStart() {
		return start;
	}
	
	public void loopSpace() {
		if(space > 60) {
			space = space - 60;
		}
	}
	
	 public void safeZone() {
		 if(counter >= 60 && safe == false) {
			 safe = true;
			 if(space < 100) {
				 space = space + 100;
			 }
		 } else if(counter < 60 && safe == true) {
			 safe = false;
			 if(space > 100) {
				 space = space - 100;
			 }
		 }
	 }
	 
	 public void reset() {
			space = 0;
			counter = 1;
			start = false;
			safe = false;
	 }
	 
	 public void done(int x) {
		 if(counter == 66) {
			 done = true;
		 } else if(counter > 66) {
			 counter = counter - x;
			 space = space - x;
		 }
	 }
	 
		public int doEffect(int x, int y) {
			System.out.println(x + ", " + y);
			if(x == 3) {
				if(y == 1) {
					done = true;
				}
				else if(y == 2) {
					return 1;
				}
			}
			else if(x == 5) {
				if(y == 1) {
					return 2;
				}
				else if(y == 2) {
					return 3;
				}
			}
			else if(x == 8) {
				if(y == 1) {
					return 1;
				}
				else if(y == 2) {
					return 4;
				}
			}
			else if(x == 12) {
				if(y == 1) {
					if(start == true) {
						space = space + 24;
						counter = counter + 24;
					}
				}
				else if(y == 2) {
					done = true;
				}
			}
			return 0;
		}
	 
	 public boolean getDone() {
		 return done;
	 }
}